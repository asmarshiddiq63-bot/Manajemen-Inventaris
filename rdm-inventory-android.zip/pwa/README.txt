RDM Inventory & Aset - Aplikasi Android (PWA)

CARA PASANG (gratis):
1. Upload SELURUH isi folder ini ke hosting HTTPS, mis. Netlify Drop (app.netlify.com/drop),
   Cloudflare Pages, atau GitHub Pages.
2. Buka alamatnya di Chrome Android -> menu titik tiga -> "Instal aplikasi" / "Tambahkan ke layar utama".
3. Aplikasi muncul di layar utama, berjalan layar penuh, dan tetap bisa dibuka offline setelah dibuka sekali.

OPSIONAL - jadi file APK: buka pwabuilder.com, masukkan alamat hosting Anda, pilih Android, unduh paketnya.

CATATAN: Data tersimpan di penyimpanan browser tiap perangkat (tidak tersinkron antar HP).
Gunakan menu Ekspor Excel untuk arsip/backup berkala.
